let l0op;
console.log("ответ на задачу №3")
for ( l0op = 0; l0op <= 9; l0op++){
    console.log(l0op);
}